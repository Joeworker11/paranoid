#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QKeyEvent>
#include <QDebug>
#include <cmath>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->stackedWidget->setCurrentIndex(0);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::startGame()
{
    ui->stackedWidget->setCurrentIndex(1);
    started = true;
    mainScene = new QGraphicsScene(this);
    mainScene->setSceneRect(ui->graphicsView->rect());
    ui->graphicsView->setAlignment(Qt::AlignTop | Qt::AlignLeft);
    life_counter = 3;
    brickcount = 0;
    ball = mainScene->addEllipse(0, 0, 20, 20, QPen(Qt::black), QBrush(QColor(120, 230, 140)));
    tray = mainScene->addRect(0, 0, 100, 10, QPen(Qt::blue), QBrush(QColor(140, 200, 250)));

    for(int j = 0; j < 6; j++){
        for(int i = 0; i < 20; i++){
            QGraphicsRectItem* brick;
            brick = mainScene->addRect(0, 0, 40, 20, QPen(Qt::red), QBrush(Qt::black));
            brick->setPos(20 + i*50, 300-30*j);
            bricklist.append(brick);
            brickcount ++;
        }
    }

    tray->setPos(50, 750);
    ball->setPos(50 + tray->boundingRect().width()/2, 750 - ball->boundingRect().height());
    vx =0;
    vy =0;
    ui->graphicsView->setScene(mainScene);
    timer = new QTimer;
    lifelabel = mainScene->addText("Hátralevő élet: 3");
    lifelabel->setPos(10,10);

    connect(timer, SIGNAL(timeout()), this, SLOT(move_Ball()));

    timer->start(10);

}

void MainWindow::endGame()
{

    ui->stackedWidget->setCurrentIndex(2);
    timer->stop();
}



void MainWindow::on_startButton_clicked()
{

    startGame();
}

void MainWindow::move_Ball()
{
   ball->moveBy(vx,vy);

   if (ball->x()<0){
       vx*=-1;
   }
   if(ball->y()<0){
       vy*=-1; 
   }


   if(brickcount == 0){

       ui->stackedWidget->setCurrentIndex(2);
       timer->stop();
       ui->label->setText("Te nyertél! Gratulálok {^_^}");


   }

   QList<QGraphicsItem*> col = ball->collidingItems();
   if (col.contains(tray)){
       float ball_mid = ball->x() + ball->boundingRect().width() / 2;
       float tray_mid = tray->x() + tray->boundingRect().width() / 2;

       vy*=-1 + (tray_mid - ball_mid)/tray->boundingRect().width();
   }
   normalize_ballspeed();

   if(ball->x()>ui->graphicsView->width()){
       vx*=-1;

   }

   for(QGraphicsItem*item: col){
       QGraphicsRectItem*box=dynamic_cast<QGraphicsRectItem*>(item);
       if(box != nullptr){
           qDebug() << "Crash" << QString::number(box->x());
           if(bricklist.contains(box)){
               qDebug() << "Crash -- box" << QString::number(box->x());
               collideWithBrick(box);
           }
       }
   }

   qDebug() << ball->x() << ball->y();

//    if(ball->pos()== tray->pos()){

//    }

//   if(col.contains(brick))

   if (life_counter == 0){
       endGame();
   }
   if(ball->y() + ball->boundingRect().height() -2 >=tray->y() && !col.contains(tray)){
       life_counter-=1;
       lifelabel->setPlainText("Hátralevő életek: " + QString::number(life_counter));
       vy*=-1;
   }

}

void MainWindow::keyPressEvent(QKeyEvent* event){
    if(event->key() == Qt::Key_D && (tray->x() + tray->boundingRect().width() < ui->graphicsView->width()) ){
        tray->moveBy(10, 0);
    }
    if(event->key() == Qt::Key_A && (tray->x() > 0)){
        tray->moveBy(-10, 0);
    }
    if(event->key() == Qt::Key_Space ){
        vx = -1;
        vy = -1;
    }
}

void MainWindow::resizeEvent(QResizeEvent* event){
    QMainWindow::resizeEvent(event);
    if(started){
        tray->setPos(tray->x(), ui->graphicsView->height()-50);
    }
}

void MainWindow::collideWithBrick(QGraphicsRectItem*brick)
{
    mainScene->removeItem(brick);


    brickcount -= 1;

    if(ball->y() + ball->boundingRect().height() <= brick->y() || ball->y() >= brick->y() + brick->boundingRect().height() )
    { //ha a doboz felett vagy alatt van a labda
        vx*=-1;
    } else { //ha doboz mellett van
        vy*=-1;
    }
    //brick->setPos(-1000,0);
    // tégla eltűntetése


}



void MainWindow::on_pushButton_clicked()
{
    startGame();
}


void MainWindow::on_pushButton_2_clicked()
{
    exit(0);
}

void MainWindow::normalize_ballspeed()
{
    float length = std::sqrt(vx*vx + vy *vy);
    if (length==0) {
        length=1;
    }
    vx *= ballspeed/length;
    vy *= ballspeed/length;

}

