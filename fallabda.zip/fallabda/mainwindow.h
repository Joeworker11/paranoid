#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsEllipseItem>
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void startGame();
    void endGame();




private slots:
    void on_startButton_clicked();
    void move_Ball();
    void keyPressEvent(QKeyEvent* event);
    void resizeEvent(QResizeEvent* event);
    void collideWithBrick(QGraphicsRectItem*brick);


    void on_pushButton_clicked();

    void on_pushButton_2_clicked();
    void normalize_ballspeed();

private:
    Ui::MainWindow *ui;
    QGraphicsEllipseItem* ball;
    QGraphicsRectItem* tray;
    QList <QGraphicsRectItem*> bricklist;
    QTimer *timer;
    bool started = false;
    float ballspeed = 2;
    int brickcount = 0;
    float vx = -1.5;
    float vy = -1.5;
    int life_counter;
    QGraphicsTextItem *lifelabel;
    QGraphicsScene * mainScene;


};
#endif // MAINWINDOW_H
